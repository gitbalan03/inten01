# ⚡ TaskFlow — Full Stack Task Management App

A complete full-stack task management application built with **React.js**, **Node.js**, **Express.js**, and **MongoDB**.

---

## 🏗️ Tech Stack

| Layer     | Technology                              |
|-----------|-----------------------------------------|
| Frontend  | React 18, React Router 6, Axios         |
| Backend   | Node.js, Express.js, Morgan             |
| Database  | MongoDB + Mongoose ODM                  |
| Auth      | JWT (jsonwebtoken) + bcryptjs           |
| Validation| express-validator                       |

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- MongoDB (local or [MongoDB Atlas](https://cloud.mongodb.com) free tier)

---

### 1. Clone and install

```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

---

### 2. Configure environment variables

```bash
# In /backend, copy the example file:
cp .env.example .env
```

Edit `/backend/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/taskflow
JWT_SECRET=your_super_secret_key_here_make_it_long
JWT_EXPIRES_IN=7d
NODE_ENV=development
```

> For MongoDB Atlas, replace `MONGODB_URI` with your Atlas connection string.

```bash
# In /frontend, copy the example file:
cp .env.example .env
```

Edit `/frontend/.env`:
```
REACT_APP_API_URL=http://localhost:5000/api
```

---

### 3. Run the app

Open **two terminals**:

**Terminal 1 — Backend:**
```bash
cd backend
npm run dev
# Server starts at http://localhost:5000
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm start
# App opens at http://localhost:3000
```

---

## 📁 Project Structure

```
taskflow/
├── backend/
│   ├── config/
│   │   └── db.js              # MongoDB connection
│   ├── middleware/
│   │   └── auth.js            # JWT protect middleware
│   ├── models/
│   │   ├── User.js            # User schema (bcrypt hashed password)
│   │   └── Task.js            # Task schema with indexes
│   ├── routes/
│   │   ├── auth.js            # POST /register, /login, GET /me
│   │   ├── tasks.js           # Full CRUD + toggle + filters
│   │   └── users.js           # Profile + password update
│   ├── server.js              # Express app entry point
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── Sidebar.jsx    # Navigation sidebar
    │   │   ├── TaskCard.jsx   # Individual task card
    │   │   └── TaskModal.jsx  # Create/edit task form
    │   ├── context/
    │   │   ├── AuthContext.js # Auth state + login/logout
    │   │   └── TaskContext.js # Task CRUD state
    │   ├── pages/
    │   │   ├── AuthPage.jsx   # Login + Register tabs
    │   │   ├── Dashboard.jsx  # Stats + recent tasks
    │   │   └── TasksPage.jsx  # Full task list + filters
    │   ├── utils/
    │   │   └── api.js         # Axios instance + interceptors
    │   ├── App.js             # Router + layout
    │   ├── App.css            # All styles
    │   └── index.js           # React entry point
    ├── .env.example
    └── package.json
```

---

## 🔌 API Endpoints

### Auth
| Method | Endpoint              | Access  | Description          |
|--------|-----------------------|---------|----------------------|
| POST   | /api/auth/register    | Public  | Register new user    |
| POST   | /api/auth/login       | Public  | Login + get JWT      |
| GET    | /api/auth/me          | Private | Get current user     |

### Tasks
| Method | Endpoint              | Access  | Description                    |
|--------|-----------------------|---------|--------------------------------|
| GET    | /api/tasks            | Private | List tasks (filter, paginate)  |
| POST   | /api/tasks            | Private | Create new task                |
| GET    | /api/tasks/:id        | Private | Get single task                |
| PUT    | /api/tasks/:id        | Private | Update task                    |
| DELETE | /api/tasks/:id        | Private | Delete task                    |
| PATCH  | /api/tasks/:id/toggle | Private | Toggle complete/incomplete     |

### Users
| Method | Endpoint              | Access  | Description          |
|--------|-----------------------|---------|----------------------|
| GET    | /api/users/profile    | Private | Get profile          |
| PUT    | /api/users/profile    | Private | Update profile       |
| PUT    | /api/users/password   | Private | Change password      |

**Query parameters for GET /api/tasks:**
```
?status=todo|inprogress|completed|all
&priority=low|medium|high|all
&search=keyword
&sortBy=createdAt|dueDate|priority
&order=asc|desc
&page=1&limit=20
```

---

## ✨ Features

- ✅ JWT Authentication (register, login, auto-logout on expiry)
- ✅ Full task CRUD — title, description, priority, status, due date
- ✅ Filter by status and priority, live search
- ✅ Dashboard with stats: total, completed, in-progress, overdue
- ✅ Completion progress bar and attention panel
- ✅ One-click task toggle (complete ↔ incomplete)
- ✅ Responsive — desktop sidebar + mobile bottom nav
- ✅ Mongoose indexes for fast queries
- ✅ Input validation on both frontend and backend
- ✅ Global error handling and 401 auto-redirect

---

## 🚢 Deployment

### Backend (Railway / Render / Heroku)
1. Set environment variables in your hosting dashboard
2. Set `NODE_ENV=production`
3. Deploy `/backend` folder

### Frontend (Vercel / Netlify)
1. Set `REACT_APP_API_URL=https://your-backend-url.com/api`
2. Build command: `npm run build`
3. Deploy `/frontend` folder

---

## 📜 License
MIT — free to use and modify.
