import React from 'react';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ page, setPage }) {
  const { user, logout } = useAuth();
  const initials = user?.name?.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2) || 'U';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', emoji: '⊞' },
    { id: 'tasks', label: 'Tasks', emoji: '✔' },
  ];

  return (
    <nav className="sidebar">
      <div className="sidebar-logo"><span className="logo-accent">Task</span>Flow</div>

      <div className="nav-items">
        {navItems.map((n) => (
          <button
            key={n.id}
            className={`nav-item ${page === n.id ? 'nav-item-active' : ''}`}
            onClick={() => setPage(n.id)}
          >
            <span className="nav-emoji">{n.emoji}</span>
            <span className="nav-label">{n.label}</span>
          </button>
        ))}
      </div>

      <div className="sidebar-bottom">
        <button className="nav-item" onClick={logout}>
          <span className="nav-emoji">→</span>
          <span className="nav-label">Logout</span>
        </button>
        <div className="sidebar-user">
          <div className="avatar">{initials}</div>
          <div className="user-info">
            <p className="user-name">{user?.name}</p>
            <p className="user-email">{user?.email}</p>
          </div>
        </div>
      </div>
    </nav>
  );
}
