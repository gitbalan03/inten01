import React from 'react';

function getDueDateInfo(dueDate) {
  if (!dueDate) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate); due.setHours(0, 0, 0, 0);
  const diff = Math.round((due - today) / 86400000);
  if (diff < 0) return { label: `${Math.abs(diff)}d overdue`, type: 'overdue' };
  if (diff === 0) return { label: 'Due today', type: 'overdue' };
  if (diff <= 3) return { label: `Due in ${diff}d`, type: 'soon' };
  return { label: due.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), type: 'normal' };
}

export default function TaskCard({ task, onEdit, onDelete, onToggle }) {
  const dueInfo = getDueDateInfo(task.dueDate);
  const isCompleted = task.status === 'completed';

  return (
    <div className={`task-card ${isCompleted ? 'task-card-done' : ''}`}>
      <div className="task-card-inner">
        <button
          className={`checkbox ${isCompleted ? 'checkbox-checked' : ''}`}
          onClick={() => onToggle(task._id)}
          aria-label={isCompleted ? 'Mark incomplete' : 'Mark complete'}
        >
          {isCompleted && '✓'}
        </button>

        <div className="task-body">
          <div className="task-top">
            <p className={`task-title ${isCompleted ? 'task-title-done' : ''}`}>{task.title}</p>
            <div className="task-actions">
              <button className="btn-icon" onClick={() => onEdit(task)} title="Edit">✏️</button>
              <button className="btn-icon btn-icon-danger" onClick={() => onDelete(task._id)} title="Delete">🗑️</button>
            </div>
          </div>

          {task.description && <p className="task-desc">{task.description}</p>}

          <div className="task-meta">
            <span className={`badge badge-${task.priority}`}>{task.priority}</span>
            <span className={`badge badge-status-${task.status}`}>
              {task.status === 'inprogress' ? 'In Progress' : task.status === 'todo' ? 'To Do' : 'Completed'}
            </span>
            {dueInfo && (
              <span className={`due-label due-${dueInfo.type}`}>
                📅 {dueInfo.label}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
