import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { AuthProvider, useAuth } from './context/AuthContext';
import { TaskProvider, useTask } from './context/TaskContext';

import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import TasksPage from './pages/TasksPage';
import Sidebar from './components/Sidebar';
import TaskModal from './components/TaskModal';

import './App.css';

function ProtectedLayout() {
  const { user } = useAuth();
  const { createTask, fetchTasks } = useTask();
  const [page, setPage] = useState('dashboard');
  const [showNewTask, setShowNewTask] = useState(false);

  if (!user) return <Navigate to="/login" replace />;

  const handleCreateTask = async (formData) => {
    try {
      await createTask(formData);
      setShowNewTask(false);
      toast.success('Task created! ✓');
      fetchTasks();
    } catch (err) {
      toast.error('Failed to create task');
    }
  };

  return (
    <div className="app-layout">
      <Sidebar page={page} setPage={setPage} />
      <main className="main-content">
        {page === 'dashboard' && <Dashboard onNewTask={() => setShowNewTask(true)} />}
        {page === 'tasks' && <TasksPage onNewTask={() => setShowNewTask(true)} />}
      </main>
      {showNewTask && (
        <TaskModal onSave={handleCreateTask} onClose={() => setShowNewTask(false)} />
      )}
      <ToastContainer position="bottom-right" theme="dark" autoClose={2500} />
    </div>
  );
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <AuthPage />} />
      <Route path="/*" element={<ProtectedLayout />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <TaskProvider>
          <AppRoutes />
        </TaskProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
