import React, { useEffect, useState } from 'react';
import { useTask } from '../context/TaskContext';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';

export default function TasksPage({ onNewTask }) {
  const { tasks, loading, filters, fetchTasks, updateFilters, updateTask, deleteTask, toggleTask } = useTask();
  const [editTask, setEditTask] = useState(null);

  useEffect(() => { fetchTasks(); }, [filters]);

  const handleEdit = (task) => setEditTask(task);
  const handleSaveEdit = async (formData) => {
    await updateTask(editTask._id, formData);
    setEditTask(null);
  };

  return (
    <div>
      <div className="section-header">
        <h1 className="section-title">
          All Tasks <span className="task-count">({tasks.length})</span>
        </h1>
        <button className="btn-primary" onClick={onNewTask}>+ New Task</button>
      </div>

      <div className="filters-container">
        <div className="search-input">
          <span className="search-icon">🔍</span>
          <input
            value={filters.search}
            onChange={(e) => updateFilters({ search: e.target.value })}
            placeholder="Search tasks..."
          />
        </div>

        <div className="filter-row">
          <span className="filter-label">Status:</span>
          <div className="filter-bar">
            {['all', 'todo', 'inprogress', 'completed'].map((s) => (
              <button
                key={s}
                className={`filter-btn ${filters.status === s ? 'active' : ''}`}
                onClick={() => updateFilters({ status: s })}
              >
                {s === 'all' ? 'All' : s === 'todo' ? 'To Do' : s === 'inprogress' ? 'In Progress' : 'Completed'}
              </button>
            ))}
          </div>
        </div>

        <div className="filter-row">
          <span className="filter-label">Priority:</span>
          <div className="filter-bar">
            {['all', 'high', 'medium', 'low'].map((p) => (
              <button
                key={p}
                className={`filter-btn ${filters.priority === p ? 'active' : ''}`}
                onClick={() => updateFilters({ priority: p })}
              >
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="loading-spinner">Loading tasks...</div>
      ) : tasks.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🔍</div>
          <p>No tasks found. Adjust filters or create a new task.</p>
        </div>
      ) : (
        <div className="task-list">
          {tasks.map((t) => (
            <TaskCard
              key={t._id}
              task={t}
              onEdit={handleEdit}
              onDelete={deleteTask}
              onToggle={toggleTask}
            />
          ))}
        </div>
      )}

      {editTask && (
        <TaskModal task={editTask} onSave={handleSaveEdit} onClose={() => setEditTask(null)} />
      )}
    </div>
  );
}
