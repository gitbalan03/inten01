import React, { useEffect } from 'react';
import { useTask } from '../context/TaskContext';

export default function Dashboard({ onNewTask }) {
  const { tasks, stats, fetchTasks } = useTask();

  useEffect(() => { fetchTasks(); }, []);

  const pct = stats.total ? Math.round((stats.completed / stats.total) * 100) : 0;

  const overdue = tasks.filter((t) => {
    if (!t.dueDate || t.status === 'completed') return false;
    return new Date(t.dueDate) < new Date();
  }).length;

  const recentTasks = [...tasks]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  return (
    <div>
      <div className="section-header">
        <div>
          <h1 className="section-title">Dashboard</h1>
          <p className="section-subtitle">Here's what's happening today</p>
        </div>
        <button className="btn-primary" onClick={onNewTask}>+ New Task</button>
      </div>

      <div className="stats-grid">
        {[
          { label: 'Total Tasks', value: stats.total, emoji: '📋', color: 'accent' },
          { label: 'Completed', value: stats.completed, emoji: '✅', color: 'green' },
          { label: 'In Progress', value: stats.inprogress, emoji: '⚡', color: 'blue' },
          { label: 'To Do', value: stats.todo, emoji: '📝', color: 'muted' },
        ].map((s) => (
          <div key={s.label} className={`stat-card stat-${s.color}`}>
            <span className="stat-emoji">{s.emoji}</span>
            <div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="dashboard-grid">
        <div className="card">
          <h3 className="card-heading">Completion Progress</h3>
          <div className="progress-header">
            <span className="progress-pct">{pct}%</span>
            <span className="progress-sub">{stats.completed}/{stats.total} tasks</span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${pct}%` }} />
          </div>
          <div className="progress-legend">
            <span>{stats.todo} to do</span>
            <span>{stats.inprogress} in progress</span>
            <span>{stats.completed} done</span>
          </div>
        </div>

        <div className="card">
          <h3 className="card-heading">Attention Needed</h3>
          <div className="attention-items">
            <div className="attention-item attention-red">
              <span>🚨 Overdue tasks</span>
              <strong>{overdue}</strong>
            </div>
            <div className="attention-item attention-amber">
              <span>🔴 High priority</span>
              <strong>{stats.high || 0}</strong>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="card-heading">Recent Tasks</h3>
        {recentTasks.length === 0 ? (
          <p className="empty-text">No tasks yet. Create your first task!</p>
        ) : (
          <div className="recent-list">
            {recentTasks.map((t) => (
              <div key={t._id} className="recent-item">
                <span className={`badge badge-${t.priority}`}>{t.priority}</span>
                <p className={`recent-title ${t.status === 'completed' ? 'strikethrough' : ''}`}>{t.title}</p>
                <span className={`badge badge-status-${t.status}`}>
                  {t.status === 'inprogress' ? 'In Progress' : t.status === 'todo' ? 'To Do' : 'Done'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
