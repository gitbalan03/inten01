import React, { createContext, useContext, useState, useCallback } from 'react';
import api from '../utils/api';

const TaskContext = createContext(null);

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ total: 0, completed: 0, inprogress: 0, todo: 0, high: 0 });
  const [pagination, setPagination] = useState({ total: 0, page: 1, pages: 1 });
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ status: 'all', priority: 'all', search: '', sortBy: 'createdAt', order: 'desc' });

  const fetchTasks = useCallback(async (overrides = {}) => {
    setLoading(true);
    try {
      const params = { ...filters, ...overrides };
      const { data } = await api.get('/tasks', { params });
      setTasks(data.data);
      setStats(data.stats);
      setPagination(data.pagination);
    } catch (err) {
      console.error('Failed to fetch tasks:', err);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const createTask = async (taskData) => {
    const { data } = await api.post('/tasks', taskData);
    setTasks((prev) => [data.data, ...prev]);
    setStats((s) => ({ ...s, total: s.total + 1, [data.data.status]: s[data.data.status] + 1 }));
    return data.data;
  };

  const updateTask = async (id, taskData) => {
    const { data } = await api.put(`/tasks/${id}`, taskData);
    setTasks((prev) => prev.map((t) => (t._id === id ? data.data : t)));
    return data.data;
  };

  const deleteTask = async (id) => {
    const task = tasks.find((t) => t._id === id);
    await api.delete(`/tasks/${id}`);
    setTasks((prev) => prev.filter((t) => t._id !== id));
    if (task) setStats((s) => ({ ...s, total: s.total - 1, [task.status]: Math.max(0, s[task.status] - 1) }));
  };

  const toggleTask = async (id) => {
    const { data } = await api.patch(`/tasks/${id}/toggle`);
    setTasks((prev) => prev.map((t) => (t._id === id ? data.data : t)));
    return data.data;
  };

  const updateFilters = (newFilters) => {
    setFilters((prev) => ({ ...prev, ...newFilters }));
  };

  return (
    <TaskContext.Provider value={{ tasks, stats, pagination, loading, filters, fetchTasks, createTask, updateTask, deleteTask, toggleTask, updateFilters }}>
      {children}
    </TaskContext.Provider>
  );
};

export const useTask = () => {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error('useTask must be used within TaskProvider');
  return ctx;
};
